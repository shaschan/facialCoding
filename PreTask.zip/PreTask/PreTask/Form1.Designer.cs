﻿namespace PreTask
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.upload1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.axWindowsMediaPlayer1 = new AxWMPLib.AxWindowsMediaPlayer();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.axWindowsMediaPlayer2 = new AxWMPLib.AxWindowsMediaPlayer();
            this.upload = new System.Windows.Forms.Button();
            this.sad = new System.Windows.Forms.Button();
            this.happy = new System.Windows.Forms.Button();
            this.angry = new System.Windows.Forms.Button();
            this.fear = new System.Windows.Forms.Button();
            this.disgust = new System.Windows.Forms.Button();
            this.surprise = new System.Windows.Forms.Button();
            this.contempt = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer2)).BeginInit();
            this.SuspendLayout();
            // 
            // upload1
            // 
            this.upload1.Location = new System.Drawing.Point(537, 9);
            this.upload1.Name = "upload1";
            this.upload1.Size = new System.Drawing.Size(162, 32);
            this.upload1.TabIndex = 0;
            this.upload1.Text = "UPLOAD";
            this.upload1.UseVisualStyleBackColor = true;
            this.upload1.Click += new System.EventHandler(this.upload1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(59, 9);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(463, 26);
            this.textBox1.TabIndex = 1;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(649, 76);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(130, 34);
            this.button2.TabIndex = 2;
            this.button2.Text = "Start";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(649, 116);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(130, 32);
            this.button3.TabIndex = 3;
            this.button3.Text = "Stop";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // axWindowsMediaPlayer1
            // 
            this.axWindowsMediaPlayer1.Enabled = true;
            this.axWindowsMediaPlayer1.Location = new System.Drawing.Point(59, 41);
            this.axWindowsMediaPlayer1.Name = "axWindowsMediaPlayer1";
            this.axWindowsMediaPlayer1.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWindowsMediaPlayer1.OcxState")));
            this.axWindowsMediaPlayer1.Size = new System.Drawing.Size(342, 208);
            this.axWindowsMediaPlayer1.TabIndex = 1;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(59, 353);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(463, 26);
            this.textBox2.TabIndex = 8;
            // 
            // axWindowsMediaPlayer2
            // 
            this.axWindowsMediaPlayer2.Enabled = true;
            this.axWindowsMediaPlayer2.Location = new System.Drawing.Point(59, 385);
            this.axWindowsMediaPlayer2.Name = "axWindowsMediaPlayer2";
            this.axWindowsMediaPlayer2.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("axWindowsMediaPlayer2.OcxState")));
            this.axWindowsMediaPlayer2.Size = new System.Drawing.Size(342, 188);
            this.axWindowsMediaPlayer2.TabIndex = 1;
            // 
            // upload
            // 
            this.upload.Location = new System.Drawing.Point(537, 343);
            this.upload.Name = "upload";
            this.upload.Size = new System.Drawing.Size(162, 33);
            this.upload.TabIndex = 11;
            this.upload.Text = "UPLOAD";
            this.upload.UseVisualStyleBackColor = true;
            this.upload.Click += new System.EventHandler(this.upload_Click);
            // 
            // sad
            // 
            this.sad.Location = new System.Drawing.Point(649, 385);
            this.sad.Name = "sad";
            this.sad.Size = new System.Drawing.Size(130, 28);
            this.sad.TabIndex = 12;
            this.sad.Text = "Sad";
            this.sad.UseVisualStyleBackColor = true;
            // 
            // happy
            // 
            this.happy.Location = new System.Drawing.Point(649, 419);
            this.happy.Name = "happy";
            this.happy.Size = new System.Drawing.Size(130, 28);
            this.happy.TabIndex = 13;
            this.happy.Text = "Happy";
            this.happy.UseVisualStyleBackColor = true;
            // 
            // angry
            // 
            this.angry.Location = new System.Drawing.Point(649, 453);
            this.angry.Name = "angry";
            this.angry.Size = new System.Drawing.Size(130, 28);
            this.angry.TabIndex = 14;
            this.angry.Text = "Angry";
            this.angry.UseVisualStyleBackColor = true;
            // 
            // fear
            // 
            this.fear.Location = new System.Drawing.Point(649, 487);
            this.fear.Name = "fear";
            this.fear.Size = new System.Drawing.Size(130, 27);
            this.fear.TabIndex = 15;
            this.fear.Text = "Fear";
            this.fear.UseVisualStyleBackColor = true;
            // 
            // disgust
            // 
            this.disgust.Location = new System.Drawing.Point(649, 520);
            this.disgust.Name = "disgust";
            this.disgust.Size = new System.Drawing.Size(130, 27);
            this.disgust.TabIndex = 16;
            this.disgust.Text = "Disgust";
            this.disgust.UseVisualStyleBackColor = true;
            // 
            // surprise
            // 
            this.surprise.Location = new System.Drawing.Point(649, 553);
            this.surprise.Name = "surprise";
            this.surprise.Size = new System.Drawing.Size(130, 32);
            this.surprise.TabIndex = 17;
            this.surprise.Text = "Surprise";
            this.surprise.UseVisualStyleBackColor = true;
            // 
            // contempt
            // 
            this.contempt.Location = new System.Drawing.Point(649, 591);
            this.contempt.Name = "contempt";
            this.contempt.Size = new System.Drawing.Size(130, 32);
            this.contempt.TabIndex = 18;
            this.contempt.Text = "Contempt";
            this.contempt.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(791, 635);
            this.Controls.Add(this.contempt);
            this.Controls.Add(this.surprise);
            this.Controls.Add(this.disgust);
            this.Controls.Add(this.fear);
            this.Controls.Add(this.angry);
            this.Controls.Add(this.happy);
            this.Controls.Add(this.sad);
            this.Controls.Add(this.upload);
            this.Controls.Add(this.axWindowsMediaPlayer2);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.axWindowsMediaPlayer1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.upload1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.axWindowsMediaPlayer2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button upload1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private AxWMPLib.AxWindowsMediaPlayer axWindowsMediaPlayer1;
        private System.Windows.Forms.TextBox textBox2;
        private AxWMPLib.AxWindowsMediaPlayer axWindowsMediaPlayer2;
        private System.Windows.Forms.Button upload;
        private System.Windows.Forms.Button sad;
        private System.Windows.Forms.Button happy;
        private System.Windows.Forms.Button angry;
        private System.Windows.Forms.Button fear;
        private System.Windows.Forms.Button disgust;
        private System.Windows.Forms.Button surprise;
        private System.Windows.Forms.Button contempt;
    }
}

