﻿using System;
using System.Collections;
using System.Drawing;
using System.Windows.Forms;
using Exc = Microsoft.Office.Interop.Excel;

namespace PreTask
{

    public partial class Form1 : Form
    {
      //  Hashtable data = new Hashtable();
        ArrayList timeframe, emotions;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            timeframe = new ArrayList();
            emotions = new ArrayList();
            fetchData();
        }

        private void upload1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.textBox1.Text = openFileDialog1.FileName;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.URL = textBox1.Text;
            axWindowsMediaPlayer1.Ctlcontrols.play();

            axWindowsMediaPlayer2.URL = textBox2.Text;
            axWindowsMediaPlayer2.Ctlcontrols.play();

            display();


        }

        private void button3_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.Ctlcontrols.stop();
            axWindowsMediaPlayer2.Ctlcontrols.stop();
        }

        private void upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog2 = new OpenFileDialog();
            if (openFileDialog2.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.textBox2.Text = openFileDialog2.FileName;
            }
        }

        private void display()
        {
            int i = 0;
            while(axWindowsMediaPlayer2.URL.Length > 0 && i < timeframe.Count)
            {
                String timeFrame = (string) timeframe[i];
                String emotion = (string) emotions[i] ;
                MessageBox.Show(timeFrame);
                MessageBox.Show(emotion);
                if (axWindowsMediaPlayer2.Ctlcontrols.currentPositionString == timeFrame)
                {
                    switch (emotion)
                    {
                        case "Surprise":
                            surprise.BackColor = Color.Red;
                            break;
                        case "Angry":
                            angry.BackColor = Color.Red;
                            break;
                        case "Happy":
                            happy.BackColor = Color.Red;
                            break;
                        case "Sad":
                            sad.BackColor = Color.Red;
                            break;
                        case "Disgust":
                            disgust.BackColor = Color.Red;
                            break;
                        case "Fear":
                            fear.BackColor = Color.Red;
                            break;
                        case "Contempt":
                            contempt.BackColor = Color.Red;
                            break;
                        default:
                            Console.WriteLine("Default case");
                            break;

                    } 
                }
                i++;
            }
        }

        private void fetchData()
        {
            
            Exc.Application xlApp;
            Exc.Workbook xlWorkBook;
            Exc.Worksheet xlWorkSheet;
            Exc.Range range;

            
            xlApp = new Exc.Application();
            xlWorkBook = xlApp.Workbooks.Open("C:/Users/Prachi Singh/Documents/Visual Studio 2015/Projects/PreTask/PreTask/demo.xlsx", 0, true, 5, "", "", true, Microsoft.Office.Interop.Excel.XlPlatform.xlWindows, "\t", false, false, 0, true, 1, 0);
            xlWorkSheet = (Exc.Worksheet)xlWorkBook.Worksheets.get_Item(1);

            range = xlWorkSheet.UsedRange;

            for (int rCnt = 2; rCnt <= range.Rows.Count; rCnt++)
            {
               String str1 = (string)(range.Cells[rCnt, 1] as Exc.Range).Value2;
               String str2 = (string)(range.Cells[rCnt, 2] as Exc.Range).Value2;
                MessageBox.Show(str1);
                MessageBox.Show(str2);
                timeframe.Add(str1);
                emotions.Add(str2);
            }

            xlWorkBook.Close(true, null, null);
            xlApp.Quit();

            releaseObject(xlWorkSheet);
            releaseObject(xlWorkBook);
            releaseObject(xlApp);
            

        }

        private void releaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
                obj = null;
            }
            catch (Exception ex)
            {
                obj = null;
                MessageBox.Show("Unable to release the Object " + ex.ToString());
            }
            finally
            {
                GC.Collect();
            }
        }

    }
}
