﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PreTask
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void upload1_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.textBox1.Text = openFileDialog1.FileName;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.URL = textBox1.Text;
            axWindowsMediaPlayer1.Ctlcontrols.play();

            axWindowsMediaPlayer2.URL = textBox2.Text;
            axWindowsMediaPlayer2.Ctlcontrols.play();

            // display(timeFrame , emotion)  (from the excel sheet)


        }

        private void button3_Click(object sender, EventArgs e)
        {
            axWindowsMediaPlayer1.Ctlcontrols.stop();
            axWindowsMediaPlayer2.Ctlcontrols.stop();
        }

        private void upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog2 = new OpenFileDialog();
            if (openFileDialog2.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                this.textBox2.Text = openFileDialog2.FileName;
            }
        }

        private void display(String timeFrame, String emotion)
        {
            if (axWindowsMediaPlayer2.playState == WMPLib.WMPPlayState.wmppsPlaying)
            {
                if (axWindowsMediaPlayer2.Ctlcontrols.currentPositionString == timeFrame)
                {
                    switch (emotion)
                    {
                        case "Surprise":
                            surprise.BackColor = Color.Red;
                            break;
                        case "Angry":
                            angry.BackColor = Color.Red;
                            break;
                        case "Happy":
                            happy.BackColor = Color.Red;
                            break;
                        case "Sad":
                            sad.BackColor = Color.Red;
                            break;
                        case "Disgust":
                            disgust.BackColor = Color.Red;
                            break;
                        case "Fear":
                            fear.BackColor = Color.Red;
                            break;
                        case "Contempt":
                            contempt.BackColor = Color.Red;
                            break;
                        default:
                            Console.WriteLine("Default case");
                            break;

                    }
                }
            }
        }
    }
}
