﻿namespace Excel
{
    internal class Workbook
    {
    }
}