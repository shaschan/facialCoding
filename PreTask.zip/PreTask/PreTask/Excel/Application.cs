﻿namespace Excel
{
    internal class Application
    {
        public Workbook ActiveWorkbook { get; internal set; }
    }
}